package Controller;

import connection.Conexion;
import procesess.HistorialDao;
import javax.swing.JTable;
import java.sql.*;


public class HistorialBO {

    private HistorialDao edao = new HistorialDao();

    public void listarHistorial(JTable tabla, String tipoBusqueda, String valorBusqueda) {
        try (Connection conn = Conexion.getConnection()) {
            // Mostrar los datos de la tabla
            edao.listarHistorial(conn, tabla, tipoBusqueda, valorBusqueda);

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
