package view;

import connection.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class JfrmRutas extends javax.swing.JInternalFrame {
    
    public JfrmRutas() {
        initComponents();
        txtId.setVisible(false);
        CargarDatos();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tblEmpleados = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtOrigen = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        txtHorarios = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        txtTarifas = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblInfoRuta = new javax.swing.JTable();

        setClosable(true);
        setTitle("Rutas");
        setToolTipText("");

        tblEmpleados.setBackground(new java.awt.Color(255, 255, 255));
        tblEmpleados.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Microsoft YaHei", 1, 14)); // NOI18N
        jLabel1.setText("RUTAS");
        tblEmpleados.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        btnActualizar.setFont(new java.awt.Font("Microsoft YaHei", 0, 11)); // NOI18N
        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.setBorder(null);
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        tblEmpleados.add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 400, 150, 30));

        jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 11)); // NOI18N
        jLabel6.setText("Horarios:");
        tblEmpleados.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 140, 60, -1));

        txtOrigen.setFont(new java.awt.Font("Microsoft YaHei", 0, 11)); // NOI18N
        txtOrigen.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblEmpleados.add(txtOrigen, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 90, 150, 30));
        tblEmpleados.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 90, 10, 30));

        txtHorarios.setFont(new java.awt.Font("Microsoft YaHei", 0, 11)); // NOI18N
        txtHorarios.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblEmpleados.add(txtHorarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 170, 150, 30));

        jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 11)); // NOI18N
        jLabel8.setText("Tarifas:");
        tblEmpleados.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 150, 50, 10));

        jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 11)); // NOI18N
        jLabel4.setText("Origen:");
        tblEmpleados.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 60, 50, 20));

        btnAgregar.setFont(new java.awt.Font("Microsoft YaHei", 0, 11)); // NOI18N
        btnAgregar.setText("AGREGAR");
        btnAgregar.setBorder(null);
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        tblEmpleados.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 400, 150, 30));

        btnNuevo.setFont(new java.awt.Font("Microsoft YaHei", 0, 11)); // NOI18N
        btnNuevo.setText("NUEVO");
        btnNuevo.setBorder(null);
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        tblEmpleados.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 440, 150, 30));

        txtTarifas.setFont(new java.awt.Font("Microsoft YaHei", 0, 11)); // NOI18N
        txtTarifas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblEmpleados.add(txtTarifas, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 170, 150, 30));

        btnEliminar.setFont(new java.awt.Font("Microsoft YaHei", 0, 11)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.setBorder(null);
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        tblEmpleados.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 440, 150, 30));

        tblInfoRuta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "Origen", "Horarios", "Tarifas"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblInfoRuta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblInfoRutaMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tblInfoRutaMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tblInfoRuta);

        tblEmpleados.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 500, 410));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tblEmpleados, javax.swing.GroupLayout.DEFAULT_SIZE, 896, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tblEmpleados, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        int id = Integer.parseInt(txtId.getText());
        String origen = txtOrigen.getText();
        String Horarios = txtHorarios.getText();
        String Tarifas = txtTarifas.getText();
        
        try {
            Connection con = Conexion.getConnection();
            PreparedStatement ps = con.prepareStatement("UPDATE TbRuta SET origen = ?, horarios = ?, tarifas = ? "
                    + "WHERE idRuta = ?");
            
            ps.setString(1, origen);
            ps.setString(2, Horarios);
            ps.setString(3, Tarifas);
            ps.setInt(4, id);
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Resgistro Modificado");
            limpiar();
            CargarDatos();
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int id = Integer.parseInt(txtId.getText());
        try {
            Connection con = Conexion.getConnection();
            PreparedStatement ps = con.prepareStatement("DELETE FROM TbRuta WHERE idRuta = ?");
            
            ps.setInt(1, id);
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Resgistro eliminado");
            limpiar();
            CargarDatos();
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String origen = txtOrigen.getText();
        String Horarios = txtHorarios.getText();
        String Tarifas = txtTarifas.getText();
        
        try {
            Connection con = Conexion.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO TbRuta (origen, horarios, tarifas) "
                    + "VALUES (?,?,?)");
            
            ps.setString(1, origen);
            ps.setString(2, Horarios);
            ps.setString(3, Tarifas);
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Registro guardado");
            limpiar();
            CargarDatos();
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        limpiar();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void tblInfoRutaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblInfoRutaMouseReleased
        

    }//GEN-LAST:event_tblInfoRutaMouseReleased

    private void tblInfoRutaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblInfoRutaMouseClicked
        
        try {
            int fila = tblInfoRuta.getSelectedRow();
            int id = Integer.parseInt(tblInfoRuta.getValueAt(fila, 0).toString());
            PreparedStatement ps;
            ResultSet rs;
            
            Connection con = Conexion.getConnection();
            
            ps = con.prepareStatement("SELECT origen, horarios, tarifas FROM TbRuta WHERE idRuta=?");
            
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                
                txtId.setText(String.valueOf(id));
                txtOrigen.setText(rs.getString("Origen"));
                txtHorarios.setText(rs.getString("Horarios"));
                txtTarifas.setText(rs.getString("Tarifas"));
                
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }

    }//GEN-LAST:event_tblInfoRutaMouseClicked
    
    public void limpiar() {
        txtOrigen.setText("");
        txtHorarios.setText("");
        txtTarifas.setText("");
    }
    
    private void CargarDatos() {
        DefaultTableModel modeloTabla = (DefaultTableModel) tblInfoRuta.getModel();
        modeloTabla.setRowCount(0);
        
        PreparedStatement ps;
        ResultSet rs;
        Connection con;
        
        try {
            con = Conexion.getConnection();
            ps = con.prepareStatement("SELECT idRuta, origen, horarios, tarifas FROM TbRuta");
            rs = ps.executeQuery();
            
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnas = rsmd.getColumnCount();
            
            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int indice = 0; indice < columnas; indice++) {
                    fila[indice] = rs.getObject(indice + 1);
                }
                modeloTabla.addRow(fila);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos: " + ex.getMessage());
            
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel tblEmpleados;
    private javax.swing.JTable tblInfoRuta;
    private javax.swing.JTextField txtHorarios;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtOrigen;
    private javax.swing.JTextField txtTarifas;
    // End of variables declaration//GEN-END:variables
}
