package model;

import java.util.*;

public class GestionChofer {

    private int idChofer;
    private String nombreChofer;
    private float edad;
    private String direccion;
    private String telefono;
    private String licenciaConducir;
    private Date fechaContra;

    public GestionChofer(int idChofer, String nombreChofer, float edad, String direccion, String telefono, String licenciaConducir, Date fechaContra) {
        this.idChofer = idChofer;
        this.nombreChofer = nombreChofer;
        this.edad = edad;
        this.direccion = direccion;
        this.telefono = telefono;
        this.licenciaConducir = licenciaConducir;
        this.fechaContra = fechaContra;
    }

    public int getIdChofer() {
        return idChofer;
    }

    public void setIdChofer(int idChofer) {
        this.idChofer = idChofer;
    }

    public String getNombreChofer() {
        return nombreChofer;
    }

    public void setNombreChofer(String nombreChofer) {
        this.nombreChofer = nombreChofer;
    }

    public float getEdad() {
        return edad;
    }

    public void setEdad(float edad) {
        this.edad = edad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getLicenciaConducir() {
        return licenciaConducir;
    }

    public void setLicenciaConducir(String licenciaConducir) {
        this.licenciaConducir = licenciaConducir;
    }

    public Date getFechaContra() {
        return fechaContra;
    }

    public void setFechaContra(Date fechaContra) {
        this.fechaContra = fechaContra;
    }

    public void finalize() throws Throwable {

    }
}
