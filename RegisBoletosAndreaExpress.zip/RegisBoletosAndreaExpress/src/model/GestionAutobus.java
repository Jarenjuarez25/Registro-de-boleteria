package model;

public class GestionAutobus {

    private int idAutobus;
    private int idTipoModelo;
    private int idTipoMarca;
    private int idChofer;
    private String numeroIdentificacion;
    private float capacidad;
    private String combustible;
    private String añoFabricacion;
    private String placa;

    public GestionAutobus(int idAutobus, int idTipoModelo, int idTipoMarca, int idChofer, String numeroIdentificacion, float capacidad, String combustible, String añoFabricacion, String placa) {
        this.idAutobus = idAutobus;
        this.idTipoModelo = idTipoModelo;
        this.idTipoMarca = idTipoMarca;
        this.idChofer = idChofer;
        this.numeroIdentificacion = numeroIdentificacion;
        this.capacidad = capacidad;
        this.combustible = combustible;
        this.añoFabricacion = añoFabricacion;
        this.placa = placa;
    }

    public int getIdAutobus() {
        return idAutobus;
    }

    public void setIdAutobus(int idAutobus) {
        this.idAutobus = idAutobus;
    }

    public int getIdTipoModelo() {
        return idTipoModelo;
    }

    public void setIdTipoModelo(int idTipoModelo) {
        this.idTipoModelo = idTipoModelo;
    }

    public int getIdTipoMarca() {
        return idTipoMarca;
    }

    public void setIdTipoMarca(int idTipoMarca) {
        this.idTipoMarca = idTipoMarca;
    }

    public int getIdChofer() {
        return idChofer;
    }

    public void setIdChofer(int idChofer) {
        this.idChofer = idChofer;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public float getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(float capacidad) {
        this.capacidad = capacidad;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public String getAñoFabricacion() {
        return añoFabricacion;
    }

    public void setAñoFabricacion(String añoFabricacion) {
        this.añoFabricacion = añoFabricacion;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

}
